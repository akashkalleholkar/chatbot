# Importing rrequired python module
import os
#import time   # commented out timestamp
import streamlit as st  # web framework
from PyPDF2 import PdfReader # python library to read PDF files
from langchain.text_splitter import RecursiveCharacterTextSplitter #splits the text into sensible chunks to use as context
from langchain_google_genai import GoogleGenerativeAIEmbeddings #used to convert text into vector form using embedding technique from google generator
import google.generativeai as genai   # using google.generativeai to access Gen AI LLM of google 
#from langchain.vectorstores import FAISS #for storing the data
from langchain_community.vectorstores import FAISS # for storing the data like database
from langchain_google_genai import ChatGoogleGenerativeAI # for answering Q & A using chat prompt and LLM like Gemini 1.5 pro or 1.5 flash 
from langchain.chains.question_answering import load_qa_chain # for loading the question answers chains 
from langchain.prompts import PromptTemplate # sets up the template of our prompts and responses form
from dotenv import load_dotenv #to load the api key from the environment
from langchain.chains import ConversationalRetrievalChain # alternate to load qa chain
from langchain.chains import LLMChain
from langchain.chains.conversational_retrieval.prompts import CONDENSE_QUESTION_PROMPT
from langchain.memory import ConversationBufferMemory # to store chat history as memory 

#Loading googles API keys
load_dotenv()
genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))

#from the pdf document extract all the text
def get_pdf_text(pdf_docs)->list:
    docs = []#creating an empty list

    for loc in pdf_docs:
        text=""
        pdf_doc = PdfReader(loc)
        for page in pdf_doc.pages:#iterate through all the documents
            text+=page.extract_text()
        docs.append(text)#seperate texts for each pdf file
    return docs

#pass the text into a text splitter function to get chunks for context matching
def get_text_chunks(docs)->dict:
    text_splitter = RecursiveCharacterTextSplitter(chunk_size = 1000, chunk_overlap = 100)
    chunks = dict()#empty dictionary
    for index, i in enumerate(docs):
        chunk = text_splitter.split_text(text=i)#split the text into chuncks
        chunks[index] = chunk#one chunk is a list for one pdf and is added to a dictionary element created earlier, this is ease of understanding and better access to each pdfs data
    return chunks

# Defining a function to load these chunks data in FAISS db in the form of embedding vectors into.
def vector_store(chunks)->None:
    '''
    Vector store for storing documents and it allows us to'upload multiple documents without replacing older one i.e. it appends to that index
    '''
    embeddings = GoogleGenerativeAIEmbeddings(model="models/embedding-001") # use gen ai embed to convert text chunks into vectors
    
    def general_vectorstore(index):
        try:
            vectorestore_common = FAISS.load_local(folder_path='faiss_index',index_name='index', embeddings=embeddings, allow_dangerous_deserialization=True)
            vectorestore_common.add_texts(index)
            vectorestore_common.save_local(folder_path='faiss_index', index_name='index') #store the embedded data in locally created folder (we can also store this in a database on cloud and such)
        except:
            index = FAISS.from_texts(index, embedding=embeddings)
            index.save_local(folder_path='faiss_index', index_name='index')

        vectorestore_common = FAISS.load_local(folder_path='faiss_index',index_name='index', embeddings=embeddings, allow_dangerous_deserialization=True)
        return vectorestore_common

    for index in chunks:
        if index == 0:
            vectorestore_common = general_vectorstore(chunks[index])
        else:
            vectorestore_common.add_texts(chunks[index])
    
    vectorestore_common.save_local(folder_path='faiss_index', index_name='index')

# Now creating a conversation retrieval chain i.e. Conversational Retrieval Chain which will allows us to create chatbots that can answer follow up questions. 
# This requires that the LLM has knowledge of the history of the conversation i.e chat history

def conv_chain(vectorestore)->ConversationalRetrievalChain:
    llm = ChatGoogleGenerativeAI(model='gemini-1.5-flash-001', temperature=0.5)
    memory = ConversationBufferMemory(memory_key='chat_history', return_messages=True)
    prompt = PromptTemplate(input_variables=['chat_history', 'question'],
                            template="Given the following conversation and a follow up question, rephrase the follow up question to be a standalone question, in its original language and answer the question in consise form and must be based on the provided context. please answer should be in paragraph form, like when bold letter is there make a new paragraph and proper spacing so it will be in readable format. If the answer is not present in the provided context, just say 'Not possible to answer from the given context', and do not generate wrong answer.\n\nChat History:\n{chat_history}\nFollow Up Input: {question}\nStandalone question:")

    chain = ConversationalRetrievalChain.from_llm(
        llm=llm,
        retriever = vectorestore.as_retriever(),
        condense_question_prompt = prompt,
        chain_type = 'stuff',
        memory=memory
    )
    return chain

# Now this function handles user interactions and generates responses based on the provided context. 
def user_input(user_question, chat_history):
    greetings = ["hi", "hello", "hey", "greetings", "good morning", "good afternoon", "good evening"]
    
# Check if the user_question is a greeting if not then Initializes the embeddings model
    if user_question.lower() in greetings:
        response = {"output_text": "Hello! How can I help you today?"}
    
    else:
        embeddings = GoogleGenerativeAIEmbeddings(model='models/embedding-001')
        # Loading the FAISS index(trained data in the form of chunks vectors) from the local database i.e. FAISS DB 
        new_db = FAISS.load_local('faiss_index', embeddings, allow_dangerous_deserialization=True) #load from the local database
        #passing the user question to connv retrieval chain
        chain = conv_chain(new_db)

        #generating a response by feeding the docs and question as the input to the model
        response = chain(
            {"question": user_question},
            return_only_outputs=True
            )
        #Appending the user's question and the generated response to the chat_history list.
        chat_history.append(user_question)
        chat_history.append(response["answer"])
    return response['answer']