#creating a sample flask application framework for generating the api key and endpoint to ordazzle chatbot
#updating file
# adding cors request headers bcz facing CORS error

# from flask import Flask, request, jsonify
# import os
# from trainapp import user_input

# app = Flask(__name__)

# # In-memory storage for API keys (use a database in production)
# api_keys = os.getenv("SECURE_API_KEY")

# # Route to handle chatbot queries with API key validation
# @app.route('/chatbot', methods=['POST'])
# def chatbot():
#     api_key = request.headers.get('x-api-key')
#     #if api_key not in api_keys:
#     #    return jsonify({'error': 'Invalid API key'}), 403

#     data = request.json
#     user_question = data.get('question')
#     chat_history = data.get('chat_history')
    
#     response = user_input(user_question, chat_history)
#     return jsonify({'response': response})

# if __name__ == '__main__':
#     host = os.getenv('FLASK_RUN_HOST')
#     port = int(os.getenv('FLASK_RUN_PORT'))
#     app.run(debug=True, host=host,port=port)

from flask import Flask, request, jsonify
from flask_cors import CORS
import os
from trainapp import user_input

app = Flask(__name__)
CORS(app)  # Enable CORS for all routes by default

# In-memory storage for API keys (use a database in production)
api_keys = os.getenv("SECURE_API_KEY")

# Route to handle chatbot queries with API key validation
@app.route('/chatbot', methods=['POST'])
def chatbot():
    api_key = request.headers.get('x-api-key')
    #if api_key not in api_keys:
    #    return jsonify({'error': 'Invalid API key'}), 403

    data = request.json
    user_question = data.get('question')
    chat_history = data.get('chat_history')
    
    response = user_input(user_question, chat_history)
    return jsonify({'response': response})

if __name__ == '__main__':
    host = os.getenv('FLASK_RUN_HOST')
    port = int(os.getenv('FLASK_RUN_PORT'))
    app.run(debug=True, host=host, port=port)
