# here in main.py file we are creating a invocation of chatbot and its user interface
# importing required functionalities
# making changes in main.py file like creating sections for user interface and admin interface.

# below is updated UI modification code that has conversational starter and direct user feedback submit option
import os
import streamlit as st
import base64
from trainapp import user_input, get_pdf_text, get_text_chunks, vector_store

def get_image_base64(image_path):
    with open(image_path, "rb") as img_file:
        return base64.b64encode(img_file.read()).decode()
    
#function for top margin 
def load_custom_css():
    with open("style.css", "r") as f:
        st.markdown(f'<style>{f.read()}</style>', unsafe_allow_html=True)

def main():
    st.set_page_config('Chat PDF')
    st.title("ETP Unify AI ChatBot")
    load_custom_css()
    # adding logo to unify chatbot page.  
    logo_path = ".static/Group 4898.png"
    #logo_path = "C:/Users/BSUGA04/Downloads/Group 4898.png"

    # Initialize session states if they are not present
    if 'chat_history' not in st.session_state:
        st.session_state.chat_history = []
    
    if 'user_feedback' not in st.session_state:
        st.session_state.user_feedback = []
    
    if "user_question" not in st.session_state:
        st.session_state.user_question = ""

    if "messages" not in st.session_state:
        st.session_state.messages = []

    # Sidebar Menu for User & Admin
    with st.sidebar:
        st.markdown(f"""<img src="data:image/png;base64,{get_image_base64(logo_path)}" width="200" height="30" style="margin-right: 1000px;"></div>""", unsafe_allow_html=True)
        role = st.radio("Select Role", ("User", "Admin"), horizontal=True)
        
        if role == "User":
            # Sample Starter Questions in Sidebar
            sample_questions = [
                "What is ETP's Unify product?",
                "How can UNIFY help with inventory management?",
                "What are the key features of ETP Unify?",
                "Tell me more about integration options with Unify.",
                "What kind of reports can I generate using Unify?"
            ]
            
            # Display starter questions as clickable options in the sidebar
            for question in sample_questions:
                if st.button(question,use_container_width=True):
                    st.session_state.messages.append({'role': 'User', 'content': question, 'avatar': '👨🏻‍💻'})
                    response = user_input(question, [])
                    st.session_state.messages.append({'role': 'Assistant', 'content': response, 'avatar': '🤖'})
                # if st.button(question, use_container_width=True):
                #     st.session_state.user_question = question  # Set the selected question to user input
    
    if role == "User":
        # Display chat history
        for message in st.session_state.messages:
            with st.chat_message(message["role"], avatar=message.get("avatar")):
                st.markdown(message["content"])

        # Use the stored user question or the user input
        user_question = st.session_state.user_question or st.chat_input("Ask a question on ETP's Unify product")
        
        # Handle the question if provided
        if user_question:
            st.session_state.user_question = ""  # Clear the stored question after usage
            with st.chat_message('User', avatar='👨🏻‍💻'):
                st.markdown(user_question)
                st.session_state.messages.append({'role': 'User', 'content': user_question, 'avatar': '👨🏻‍💻'})

            with st.chat_message('Assistant', avatar='🤖'):
                #st.empty()
                response = user_input(user_question, st.session_state.chat_history)
                st.write(response)
                st.session_state.messages.append({'role': 'Assistant', 'content': response, 'avatar': '🤖'})
                

        # Conditionally display feedback buttons if a response exists
        if st.session_state.messages and st.session_state.messages[-1]["role"] == 'Assistant':
            # Feedback Section
            user_col1, user_col2 = st.columns([2, 25])
            with user_col1:
                feedback_button_neg = st.button('👎🏻')
            with user_col2:
                feedback_button_pos = st.button('👍🏻')

            # Automatically submit feedback when either thumbs-up or thumbs-down is clicked
            if (feedback_button_neg or feedback_button_pos) and st.session_state.chat_history:
                generated_answer = st.session_state.chat_history[-1]
                user_question = st.session_state.chat_history[-2]
                question_number = len(st.session_state.chat_history)

                # Prepare feedback message
                st.session_state.user_feedback.append(f"{int(question_number / 2)}. Question: {user_question}")
                st.session_state.user_feedback.append(f" Answer: {generated_answer}")
                feedback_type = "Positive" if feedback_button_pos else "Negative"
                st.session_state.user_feedback.append(f" Feedback: {feedback_type}")

                # Submit feedback
                feedback_file = "feedback.txt"
                with open(feedback_file, "a" if os.path.exists(feedback_file) else "w", encoding="utf-8") as file:
                    for content in st.session_state.user_feedback:
                        file.write(content + "\n")
                st.session_state.user_feedback = []  # Clear feedback after submission
                st.success("Thank you for your feedback, we will add the data and retrain the model.")

    elif role == "Admin":
        # Admin Interface for uploading documents
        pdf_docs = st.file_uploader('Upload documents to train the chatbot', accept_multiple_files=True)
        if st.button('Submit Data') and pdf_docs:
            with st.spinner('Processing...'):
                raw_text = get_pdf_text(pdf_docs)
                chunks = get_text_chunks(raw_text)
                vector_store(chunks)
                st.success('Data has been successfully processed!')

if __name__ == "__main__":
    main()
